self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8f0c050afa16c44c711b2d9e2ce74fec",
    "url": "/index.html"
  },
  {
    "revision": "ff02193efd9ee265b063",
    "url": "/static/css/main.292f8c2e.chunk.css"
  },
  {
    "revision": "af51a425842680d47bf0",
    "url": "/static/js/2.092de9a1.chunk.js"
  },
  {
    "revision": "c7f92eccde8e496c47f87d08777731a5",
    "url": "/static/js/2.092de9a1.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ff02193efd9ee265b063",
    "url": "/static/js/main.b730ac2d.chunk.js"
  },
  {
    "revision": "c46025c45d4e9574a836",
    "url": "/static/js/runtime-main.cfe33f22.js"
  },
  {
    "revision": "bf10dd9dcd60320d547de0bc9afb71c9",
    "url": "/static/media/battery.bf10dd9d.svg"
  },
  {
    "revision": "048e43c2fecf482ed19bbefd72377914",
    "url": "/static/media/map.048e43c2.png"
  },
  {
    "revision": "ecb25f6dfc4280cbf869eb23b5068f37",
    "url": "/static/media/trash-mini.ecb25f6d.svg"
  },
  {
    "revision": "a1099ef2b3275192fe7ca95fa5f50da5",
    "url": "/static/media/trash.a1099ef2.svg"
  }
]);